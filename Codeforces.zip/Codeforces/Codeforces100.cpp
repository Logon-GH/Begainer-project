//https://codeforces.com/contest/149/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n,sum = 0,count = 0, f = 1;
    cin >> n;
    vector<int> arr(12);
    for(int &x : arr) cin >> x;
    sort(arr.begin(),arr.end());
    for(int i = 11; i >= 0; i--){
        sum += arr[i];
        if(n == 0) {f = 0; break;}
        count++;
        if(sum >= n){f = 0; break;}
    }
    if(f == 0) cout << count;
    else cout << -1;
 
        
    return 0;
} 
