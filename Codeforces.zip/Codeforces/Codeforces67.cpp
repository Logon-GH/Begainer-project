//https://codeforces.com/contest/339/problem/B
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    ll n,tt;
    ll sum = 0;
    cin >> n >> tt;
    vector<ll> w(tt);
        for(int i = 0; i < tt; i++){
            cin >> w[i];
        }
        sum += w[0] - 1;
        for(int i = 0; i < tt - 1; i++){
            if(w[i] <= w[i + 1]){
                sum += w[i + 1] - w[i];
            }
            else{
                sum += n - w[i];
                sum += w[i + 1] - 1;
                sum++;
            }
        }
        cout << sum;
        sum = 0;
    
        
       
    return 0;
}
