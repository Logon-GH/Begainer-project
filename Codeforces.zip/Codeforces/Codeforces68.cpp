//https://codeforces.com/contest/1999/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt, sum = 0;
    cin >> tt;
    while(tt--){
        int n;
        cin >> n;
        while(n > 0){
            sum += n % 10;
            n = n / 10;
        }
        cout << sum << "\n";
        sum = 0;
    }
    
        
       
    return 0;
}
