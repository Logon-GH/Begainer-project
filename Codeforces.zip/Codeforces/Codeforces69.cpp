//https://codeforces.com/contest/1409/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt,sum = 0;
    cin >> tt;
    while(tt--){
        int a,b,n;
        cin >> a >> b;
        n = abs(a - b);
        sum += n / 10;
        if(n % 10 == 0){
            cout << sum << '\n';
        }
        else{
            cout << sum + 1 << '\n';
        }
        sum = 0;
    }
    
        
       
    return 0;
}
