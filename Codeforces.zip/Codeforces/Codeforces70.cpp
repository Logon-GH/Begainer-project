//https://codeforces.com/contest/2176/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt, sum = 0;
    cin >> tt;
    while(tt--){
        int n;
        cin >> n;
        vector<int> a(n);
        for(int i = 0; i < n; i++){
            cin >> a[i];
        }
        int jj = a[0];
        for(int i = 1; i < n; i++){
            if(a[i] < jj){
                sum++;
            }
            else{
                jj = a[i];
            }
        }
        cout << sum << '\n';
        sum = 0;
        a.clear();
        
    }
 
    return 0;
}
