//https://codeforces.com/contest/2185/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt,n;
    cin >> tt;
    while(tt--){
        cin >> n;
        for(int i = 1; i <= n; i++){
            cout << i << " ";
        }
        cout <<'\n';
    }
        
    
 
    return 0;
}
