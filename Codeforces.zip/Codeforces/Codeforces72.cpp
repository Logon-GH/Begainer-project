//https://codeforces.com/contest/2185/problem/B
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt,n,t,max = 0;
    cin >> tt;
    while(tt--){
        cin >> n;
        for(int i = 0; i < n; i++){
            cin >> t;
                if(t > max){
                    max = t;
                }
        }
        cout << max * n << '\n';
        max = 0;
    }
        
    
 
    return 0;
}
