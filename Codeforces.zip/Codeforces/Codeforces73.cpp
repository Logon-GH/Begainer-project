//https://codeforces.com/contest/451/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n,m;
    cin >> n >> m;
    int mi = min(n , m);
    if(mi % 2 == 0){
        cout << "Malvika";
    }
    else{
        cout << "Akshat";
    }
 
    
        
    
 
    return 0;
}
