//https://codeforces.com/contest/32/problem/B
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    string t,add;
    cin >> t;
    for(int i = 0; i < t.length(); i++){
        if(t.at(i) == '.'){
            add += '0';
        }
        else if(t.at(i) == '-' && t.at(i + 1) == '.'){
            add += '1';
            i++;
        }
        else if(t.at(i) == '-' && t.at(i + 1) == '-'){
            add += '2';
            i++;
        }
    }
    cout << add;
 
    
        
    
 
    return 0;
}
