//https://codeforces.com/contest/1791/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    char c;
    cin >> tt;
    while(tt--){
        cin >> c;
        if(c == 'c' || c == 'o' || c == 'd' || c == 'e' || c == 'f' || c == 'r' || c == 's'){
            cout << "yes\n";
        }
        else{
            cout << "no\n";
        }
    }
 
    
        
    
 
    return 0;
}
