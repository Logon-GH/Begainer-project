//https://codeforces.com/contest/1512/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt,n,sum = 0;
    cin >> tt;
    while(tt--){
        cin >> n;
        vector<int> a(n);
        for(int i = 0; i < n; i++){
            cin >> a[i];
        }
        vector<int> b = a;
        sort(b.begin(), b.end());
        for(int i = 0; i < n; i++){
            if(a[i] != b[1]){
                sum = i + 1;
                break;
            }
        } 
        cout << sum << endl;
        sum = 0;
    }
    
        
    return 0;
}
