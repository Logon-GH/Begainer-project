//https://codeforces.com/contest/1760/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        vector<int> a(3);
        for(int &x : a){
            cin >> x;
        }
        sort(a.begin(), a.end());
        cout << a[1] << endl;
 
    }
    
        
    return 0;
}
