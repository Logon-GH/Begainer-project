//https://codeforces.com/contest/1915/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        int a,b,c;
        cin >> a >> b >> c;
        if(a != b){
            if(a == c){
                cout << b << endl;
            }
            else{
                cout << a << endl;
            }
        }
        else if(b != c){
            if(b == a){
                cout << c << endl;
            }
            else{
                cout << b << endl;
            }
        }
        else{
            if(a == b){
                cout << c << endl;
            }
            else{
                cout << a << endl;
            }
        }
    }
       
    return 0;
}
