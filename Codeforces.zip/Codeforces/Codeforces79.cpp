//https://codeforces.com/contest/758/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n,sum = 0;
    cin >> n;
    vector<int> a(n);
    for(int &x : a){
        cin >> x;
    }
    sort(a.begin(), a.end());
    for(int i = 0; i < n - 1; i++){
        sum += a[n - 1] - a[i];
    }
    cout << sum;
       
    return 0;
}
