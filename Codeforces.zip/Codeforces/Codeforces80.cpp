//https://codeforces.com/contest/1/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    ll n,m,a;
    cin >> n >> m >> a;
    ll length = ((n + a - 1) / a);
    ll width = ((m + a - 1) / a);
    ll total = length * width;
    cout << total;
    
       
    return 0;
}
