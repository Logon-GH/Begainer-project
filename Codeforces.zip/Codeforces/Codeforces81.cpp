//https://codeforces.com/contest/1850/problem/D
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
   int tt,sum = 0, max = 0;
   cin >> tt;
   while(tt--){
        int n ,k;
        cin >> n >> k;
        vector<int> a(n);
        for(int &x : a){
            cin >> x;
        }
        sort(a.begin(), a.end());
        for(int i = 0; i < n - 1; i++){
            if(a[i + 1] - a[i] <= k){
                sum++;
                if(sum > max){
                    max = sum;
                }
            }
            else{
                sum = 0;
            }
        }
        cout << n - (max + 1) << endl;
        sum = 0; 
        max = 0;
   }
   
    
       
    return 0;
}
