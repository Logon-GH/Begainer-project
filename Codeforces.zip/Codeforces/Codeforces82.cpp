//https://codeforces.com/contest/2091/problem/C
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        int n;
        cin >> n;
        if(n % 2 == 0){
            cout << "-1";
        }
        else{
            for(int i = n; i >= 1; i--){
                cout << i << " ";
            }
        }
        cout <<"\n";
    }
   
    
       
    return 0;
}
