//https://codeforces.com/contest/2169/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        int n, a, low = 0, high = 0;
        cin >> n >> a;
        vector<int> v(n);
        for(int i = 0; i < n; i++){
            cin >> v[i];
            if(v[i] < a){
                low++;
            }
            if(v[i] > a){
                high++;
            }
        }
        if(low > high){
            cout << a - 1 << endl;
        }
        else{
            cout << a + 1 << endl;
        }
    }
   
    
       
    return 0;
}
