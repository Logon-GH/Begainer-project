//https://codeforces.com/contest/2193/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        int n,s,x,a,sum = 0,notfound = 0;
        cin >> n >> s >> x;
        for(int i = 0; i < n; i++){
            cin >> a;
            sum += a;
        }
        while(sum != s){
            if(sum > s){
                notfound = 1;
                break;
            }
            sum += x;   
        }
 
        if(notfound == 1){
            cout << "NO\n";
        }
        else{
            cout << "YES\n";
        }
        
    }
   
    
       
    return 0;
}
