//https://codeforces.com/contest/58/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    string s, target = "hello";
    int v = 0;
    cin >> s;
    for(int i = 0; i < s.length(); i++){
        if(s[i] == target[v]){
            v++;
        }
    }
    if(v >= 5){
        cout << "YES";
    }
    else{
        cout << "NO";
    }
    
    
       
    return 0;
}
