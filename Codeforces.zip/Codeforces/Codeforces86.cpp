//https://codeforces.com/contest/43/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    string s, h, j;
    int sum = 0, num = 0;
    bool ss = true, sss = true;
    cin >> tt;
    while(tt--){
        cin >> s;
        if(ss){
            h = s;
            ss = false;
        }
        if(h == s){
            sum++;
        }
        else{
            if(sss){
                j = s;
                sss = false;
            }
            num++;
        }  
    }
    if(sum > num){
            cout << h;
        }
        else{
            cout << j;
        }
    
       
    return 0;
}
