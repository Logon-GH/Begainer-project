//https://codeforces.com/contest/160/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n;
    cin >> n;
    int sum = 0,b = 0,coin = 0;
    vector<int> a(n);
    for(int &x : a){
        cin >> x;
    }
    for(int i = 0; i < a.size(); i++){
        sum += a[i];
    }
    sort(a.begin(), a.end());
    for(int i = a.size() - 1; i >= 0; i--){
        b += a[i];
        coin++;
        if(b > sum / 2){
            break;
        }
    }
    cout << coin;
       
    return 0;
}
