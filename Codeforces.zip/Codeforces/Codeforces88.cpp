//https://codeforces.com/contest/158/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n, k, a, found = 0;
    int place = -1, sum = 0;
    cin >> n >> k;
    for(int i = 0; i < n; i++){
        cin >> a;
        if(k - 1 == i && a != 0 || place == a){
            place = a;
            sum++;
            found = 1;
        }
        else{
            if(found == 1 || a == 0){
                break;
            }
            sum++;
        }
    }
    cout << sum;
    
    
       
    return 0;
}
