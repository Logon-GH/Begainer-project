//https://codeforces.com/contest/112/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    string s1, s2;
    cin >> s1 >> s2;
    for(int i = 0; i < s1.length(); i++){
        if(s2[i] < 96){
            s2[i] += 32;
        }
        if(s1[i] < 96){
            s1[i] += 32;
        }
    }
    if(s1 == s2){
        cout << 0;
    }
    else if(s1 < s2){
        cout << -1;
    }
    else{
        cout << 1;
    }
    
    
    
       
    return 0;
}
