//https://codeforces.com/contest/617/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n;
    cin >> n;
    if(n < 6){
        cout << 1;
    }
    else if(n % 5 == 0){
        cout << n / 5;
    }
    else{
        cout << n / 5 + 1;
    }
    
    
    
       
    return 0;
}
