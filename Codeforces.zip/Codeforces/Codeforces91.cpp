//https://codeforces.com/contest/34/problem/B
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n, m, msum = 0;
    cin >> n >> m;
    vector<int> a(n);
    for(int &x : a){
        cin >> x;
    }
    sort(a.begin(), a.end());
    for(int i = 0; i < m; i++){
        if(a[i] < 0){
            msum += abs(a[i]);
        }
        else{
            break;
        }
    }
    cout << msum;
    
    
       
    return 0;
}
