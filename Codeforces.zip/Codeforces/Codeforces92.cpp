//https://codeforces.com/contest/1374/problem/B
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt, count = 0;
    ll int n, store = 1e9;
    cin >> tt;
    while(tt--){
        cin >> n;
        while(n != 1){
            if(n == 2 || n > store){
                count = -1;
                break;
            }
            if(n % 6 == 0){
                n = n / 6;
            }
            else{
                n = n * 2;
            }
            count++;
        }
        cout << count << '\n';
        count = 0;
    }
    
    
    
       
    return 0;
}
