//https://codeforces.com/contest/313/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n,l,bl,store;
    cin >> n;
    store = n;
    if(n > 0){
        cout << n;
    }
    else{
        l = abs(n % 10);
        n = n / 10;
        bl = abs(n % 10);
        if(l > bl){
            cout << store / 10;
        }
        else{
            cout << (store / 100) * 10 - l;
        }
    }
    
    
    
       
    return 0;
}
