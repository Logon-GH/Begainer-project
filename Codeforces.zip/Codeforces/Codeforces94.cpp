//https://codeforces.com/contest/500/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n, k;
    bool found = false;
    cin >> n >> k;
    vector<int> a(n);
    for(int i = 1; i < n; i++){
        cin >> a[i];
    }
    for(int i = 1; i < n;){
        if(a[i] + i == k){
            found = true;
            break;
        }
        i = i + a[i];
        if(i == k){
            break;
        }
    }
    if(found || n == 1){
        cout << "YES";
    }
    else{
        cout << "NO";
    }
    
       
    return 0;
} 
