//https://codeforces.com/contest/1374/problem/C
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
void solve(){
    int n, count = 0, sum = 0;
    string s;
    cin >> n >> s;
    for(int i = 0; i < n; i++){
        if(s[i] == 40){
            count++;
        }
        else{
            count--;
                if(count < 0){
                    sum++;
                    count = 0;
                }
        }
    }
    cout << sum << '\n';
}
 
int main(){
    ios::sync_with_stdio(false);cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        solve();
    }
    
       
    return 0;
} 
//( = 40 , ) = 41
