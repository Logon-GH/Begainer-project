//https://codeforces.com/contest/474/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    char n;
    cin >> n;
    string s;
    cin >> s;
    string ss = "qwertyuiopasdfghjkl;zxcvbnm,./";
    for(int i = 0; i < s.length(); i++){
        for(int j = 0; j < ss.length(); j++){
            if(s[i] == ss[j] && n =='R'){
                s[i] = ss[j - 1];
                break;
            }
            else if(s[i] == ss[j] && n == 'L'){
                s[i] = ss[j + 1];
                break;
            }
        }
    }
    cout << s;
        
    return 0;
} 
