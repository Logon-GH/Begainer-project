//https://codeforces.com/contest/379/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int a, b;
    std::cin >> a >> b;
    int hours = a + (a - 1) / (b - 1);
    
    std::cout << hours;
        
    return 0;
} 
