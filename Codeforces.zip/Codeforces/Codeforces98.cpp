//https://codeforces.com/contest/476/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n,m,result;
    bool found = false;
    cin >> n >> m;
    if(n % 2 == 0){
        result = n / 2;
        while(result <= n){
            if(result % m == 0){
                cout << result;
                found = true;
                break;
            }
            result++;
        }
    }
    else{
        result = (n / 2) + 1;
        while(result <= n){
            if(result % m == 0){
                cout << result;
                found = true;
                break;
            }
            result++;
        }
    }
    if(!found){
        cout << -1;
    }
        
    return 0;
} 
