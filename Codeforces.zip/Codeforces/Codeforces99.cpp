//https://codeforces.com/contest/742/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
   int n;
   cin >> n;
   if(n==0) cout << 1;
   else if(n%4==1) cout << 8;
   else if(n%4==2) cout << 4;
   else if(n%4==3) cout << 2;
   else cout << 6; 
        
    return 0;
} 
