//https://codeforces.com/contest/4/problem/A
#include<iostream>
 
int main(){
    int a;
    std::cin >> a;
    if((a-2)%2 == 0 && (a-2)>0){
        std::cout << "YES\n";
    }
    else{
        std::cout << "NO\n";
    }
    return 0;
}
