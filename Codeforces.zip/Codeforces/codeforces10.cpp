//https://codeforces.com/contest/791/problem/A
#include<iostream>
//https://codeforces.com/problemset/problem/791/A
int main(){
 
    short int a , b;
    std::cin >> a >> b;
    int sum = 0;
        if(a <= b){
            do{
                a = a * 3;
                b = b * 2;
                sum++;
 
            }while(a <= b);
        }
        std::cout << sum;
 
    return 0;
}
