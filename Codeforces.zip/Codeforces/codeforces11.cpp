//https://codeforces.com/contest/25/problem/A
#include<iostream>
//https://codeforces.com/problemset/problem/25/A
int main(){
 
    int n , num[150];
    std::cin >> n;
    int even = 0, odd = 0;
    for(int i = 0; i < n; i++){
        std::cin >> num[i];
            if(num[i] % 2 == 0){
                even++;
            }
            else{
                odd++;
            }
    }
    if(even > odd){
        for(int j = 0; j < n; j++){
            if(num[j] % 2 != 0){
                std::cout << j + 1;
            }
        }
    }
    else{
        for(int j = 0; j < n; j++){
            if(num[j] % 2 == 0){
                std::cout << j + 1;
            }
        }
    }
    
 
 
    return 0;
}
