//https://codeforces.com/contest/266/problem/A
#include<iostream>
//https://codeforces.com/problemset/problem/266/A
int main(){
 
    int n , sum = 0;
    std::string word;
    std::cin >> n;
    std::cin >> word;
    int length = word.length();
 
        if(n == length){ 
 
            for(int i = 0; i < length - 1; i++){
                if(word.at(i) == word.at(i + 1)){
                    sum++;
                }
            }
        }
        
        std::cout << sum;
 
    return 0;
}
