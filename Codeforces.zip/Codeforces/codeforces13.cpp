//https://codeforces.com/contest/118/problem/A
#include<iostream>
//https://codeforces.com/problemset/problem/118/A
void lowercase(std::string &word, int &length){
 
    for(int i = 0; i <= length - 1; i++){
            if(word.at(i) < 96){ // 'a' - 1
                word.at(i) = word.at(i) + 32;
            }
        }
 
}
int main(){
 
    std::string word;
    std::cin >> word;
    int length = word.length();
        lowercase(word,length);
        for(int j = 0; j < length; j++){
            if(word.at(j) == 97 || word.at(j) == 101 || word.at(j) == 105 || word.at(j) == 111 || word.at(j) == 117 || word.at(j) == 121){
            
            }
            else{
               std::cout << "." << word.at(j);
            }
        }
        
 
    return 0;
}
