//https://codeforces.com/contest/546/problem/A
#include<iostream>
 
int main(){
 
    int k,n,w,sum = 0; // k = price , n = amount i have, w = quintity of item
    std::cin >> k >> n >> w;
 
        for(int i = 1; i <= w; i++){ 
            sum += i * k;
        }
        if(sum < n){
            std::cout << "0";
        }
        else{
            sum = sum - n;
            std::cout << sum;
        }
            
 
    return 0;
}
