//https://codeforces.com/contest/59/problem/A
#include<iostream>
 
void lowercase(std::string &word, int &length);
void uppercase(std::string &word, int &length);
 
int main(){
 
    std::string word;
    std::cin >> word;
    int length = word.length();
    int upper = 0 , lower = 0;
        //check how many lower and uppercase are there
        for(int i = 0; i < length; i++){
            
            if(word.at(i) < 96){
                upper++;
            }
            else{
                lower++;
            }
        }
        //execute depanding on condition (reference)
        if(upper > lower){
            uppercase(word,length);
            std::cout << word;
        }
        else if(lower > upper){
            lowercase(word,length);
            std::cout << word;
        }
        else{
            lowercase(word,length);
            std::cout << word;
        }
 
    return 0;
}
void lowercase(std::string &word, int &length){
 
    for(int i = 0; i < length; i++){
        if(word.at(i) > 96){
 
        }
        else{
            word.at(i) = word.at(i) + 32;
        }
    }
}
void uppercase(std::string &word, int &length){
    for(int i = 0; i < length; i++){
        if(word.at(i) < 96){
 
        }
        else{
            word.at(i) = word.at(i) - 32;
        }
    }
}
