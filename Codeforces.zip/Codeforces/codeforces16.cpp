//https://codeforces.com/contest/977/problem/A
#include<iostream>
#include<vector>
 
int main(){
 
    long long int num;
    int proces;
 
    std::cin >> num >> proces;
    
        for(int i = 0; i < proces; i++){
            //checks if it is divadable by
            if(num % 10 == 0){
                num = num / 10;
            }
            // if its not decrement 1
            else{
                num = num - 1;
            }
        }
    std::cout << num;
 
    return 0;
}
