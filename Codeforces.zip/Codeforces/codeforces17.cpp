//https://codeforces.com/contest/69/problem/A
#include<iostream>
#include<vector>
//https://codeforces.com/problemset/problem/69/A
int main(){
    // row ?? and column 3
    int n,sum1 = 0,sum2 = 0, sum3 = 0;
    std::cin >> n;
    //declearing a 2d vector
    std::vector<std::vector<int>> v1(n, std::vector<int>(3 , 0));
        //taking input for 2d vector
        for(int i = 0; i < n; i++){
            for(int j = 0; j < 3; j++){
                std::cin >> v1[i][j];
            }
        }
        //checking vector if every sum of row == 0
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < n; j++){
                if(i == 0){
                    sum1 += v1[j][i];
                }
                else if(i == 1){
                    sum2 += v1[j][i];
                }
                else{
                    sum3 += v1[j][i];
                }
            }
        }
        //checking condition
        if(sum1 == 0 && sum2 == 0 && sum3 == 0){
            std::cout << "YES";
        }
        else{
            std::cout << "NO";
        }
 
        
        
 
    return 0;
}
