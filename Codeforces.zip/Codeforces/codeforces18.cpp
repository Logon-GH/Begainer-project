//https://codeforces.com/contest/110/problem/A
#include<iostream>
#include<vector>
 
int main(){
    
    long long int num;
    std::cin >> num;
    int sum = 0;
 
        while(num > 0){
            int lastdigit = num % 10;
                if(lastdigit == 4 || lastdigit == 7){
                    sum++;
                }
                num = num / 10;
        }
        if(sum == 4 || sum == 7){
            std::cout << "YES";
        }
        else{
            std::cout << "NO";
        }
 
    return 0;
}
