//https://codeforces.com/contest/467/problem/A
#include<iostream>
#include<string>
using namespace std;
 
int main(){
    
    int num,p,q;
    cin >> num;
    int room = 0;
        for(int i = 0; i < num; i++){
            cin >> p >> q;
                int size = q - p;
                if(size >= 2){
                    room++;
                }
        }
        cout << room;
    
    return 0;
}
