//https://codeforces.com/contest/231/problem/A
#include<iostream>
 
int main(){
 
            /*int a;
    std::cin >> a;
    if((a-2)%2 == 0 && (a-2)>0){
        std::cout << "YES\n";
    }
    else{
        std::cout << "NO\n";
    }*/
    int n,Tonya,Vasya,petya;
    int sloved = 0;
    std::cin >> n;
 
    for(int i = 0; i < n; i++){
        std::cin >> petya >> Vasya >> Tonya;
            if(petya + Vasya + Tonya == 2 || petya + Vasya + Tonya == 3){
                sloved++;
            }
    }
    std::cout << sloved;
    
    
 
 
    return 0;
}
