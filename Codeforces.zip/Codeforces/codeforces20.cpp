//https://codeforces.com/contest/344/problem/A
#include<iostream>
#include<vector>
using namespace std;
 
int main(){
    
    int num;
    cin >> num;
    vector<int> magnet(num);
    int sum = 0;
        for(int i = 0; i < num; i++){
            cin >> magnet[i];
        }
        for(int i = 0; i < num - 1; i++){
            if(magnet[i] != magnet[i + 1]){
                sum++;
            }
        }
        cout << sum + 1;
 
    
    
    return 0;
}
