//https://codeforces.com/contest/486/problem/A
#include<iostream>
#include<vector>
using namespace std;
 
int main(){
    
    long long int num;
    cin >> num;
            if(num % 2 == 0){
                cout << num / 2;
            }
            else{
                cout << -(num + 1) / 2;
            }   
    
    return 0;
}
