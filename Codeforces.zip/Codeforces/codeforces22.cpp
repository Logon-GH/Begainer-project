//https://codeforces.com/contest/122/problem/A
#include<iostream>
#include<vector>
using namespace std;
 
int main(){
    
    int num;
    cin >> num;
            if(num == 47 || num == 447 || num == 477 || num == 774 || num == 74){
                cout << "YES";
            }
            else if(num % 4 == 0 || num % 7 == 0 || num % 47 == 0 || num % 74 == 0 || num % 447 == 0){
                cout << "YES";
            }
            else{
                cout << "NO";
            }   
    
    return 0;
}
