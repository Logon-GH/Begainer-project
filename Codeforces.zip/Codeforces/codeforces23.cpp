//https://codeforces.com/contest/200/problem/B
#include<iostream>
#include<iomanip>
using namespace std;
 
int main(){
    
    int num,cocktail;
    cin >> num;
    double sum = 0;
        for(int i = 0; i < num; i++){
            cin >> cocktail;
            sum += cocktail;
        }
        cout << fixed << setprecision(12);
        cout << sum / num;
    
    return 0;
}
