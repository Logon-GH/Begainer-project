//https://codeforces.com/contest/136/problem/A
#include<iostream>
#include<vector>
using namespace std;
 
int main(){
    
    int num;
    cin >> num;
    vector<int> gift(num);
        for(int i = 0; i < num; i++){
            cin >> gift[i];
        }
        for(int i = 0; i < num; i++){
            for(int j = 0; j < num; j++){
                if(gift[j] == i + 1){
                    cout << j + 1 << " ";
                }
            }
        }
    
    
    return 0;
}
