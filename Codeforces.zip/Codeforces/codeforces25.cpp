//https://codeforces.com/contest/318/problem/A
#include<iostream>
#include<vector>
using namespace std;
 
int main(){
 
    long long int num,k;
    cin >> num >> k;
    long long int sum = (num + 1) / 2;
        if(sum < k){
            sum = 2 * (k - sum);
        }
        else{
            sum = (2 * k) - 1;
        }
        cout << sum;
 
        
 
    
    
    return 0;
}
