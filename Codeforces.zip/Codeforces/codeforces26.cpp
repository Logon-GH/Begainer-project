//https://codeforces.com/contest/228/problem/A
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
 
int main(){
 
    vector<int> num(4);
        for(int i = 0; i < 4; i++){
            cin >> num[i];
        }
        int sum = 0;
        sort(num.begin(), num.end());
        for(int j = 0; j < 3; j++){
            if(num[j] == num[j + 1]){
                sum++;
            }
        }
        cout << sum;
        
 
    
    
    return 0;
}
