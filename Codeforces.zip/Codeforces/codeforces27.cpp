//https://codeforces.com/contest/61/problem/A
#include<iostream>
#include<string>
using namespace std;
 
int main(){
 
    string num1,num2;
    cin >> num1;
    cin >> num2;
    int length = num1.length();
    string sum[length];
        for(int i = 0; i < length; i++){
            if(num1[i] == num2[i]){
                sum[i] = "0";
            }
            else if(num1[i] > num2[i]){
                sum[i] = "1";
            }
            else{
                sum[i] = "1";
            }
        }
        for(int i = 0; i < length; i++){
 
            cout << sum[i];
        }
        
 
    
    
    return 0;
}
