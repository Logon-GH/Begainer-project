//https://codeforces.com/contest/705/problem/A
#include<iostream>
#include<string>
using namespace std;
 
int main(){
 
    int num;
    cin >> num;
        if(num % 2 == 0){
            cout << "I hate that I love";
            for(int i = 2; i < num ; i = i + 2){
                cout << " that I hate that I love";
            }
        }
        else{
            cout << "I hate";
            for(int i = 1; i < num; i = i + 2){
                cout << " that I love that I hate";
            }
        }
    
        cout << " it";
 
    
    
    return 0;
}
