//https://codeforces.com/contest/71/problem/A
#include<iostream>
#include<string>
 
int main(){
 
    int input;
    std::cin >> input;
    std::string word[100];
    for(int i = 0; i < input; i++){
        std::cin >> word[i];
    }
    for(int j = 0; j < input; j++){
        int size = word[j].length();
            if(size > 10){
                char letter1 = word[j].at(0);
                char letter2 = word[j].at(size - 1);
                std::cout << letter1 << size - 2 << letter2 << std::endl;
            }
            else{
                std::cout << word[j] << std::endl;
            }
    }
 
    
    return 0;
}
