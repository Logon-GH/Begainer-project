//https://codeforces.com/contest/133/problem/A
#include<iostream>
#include<string>
using namespace std;
 
 
int main(){
 
    string P;
    cin >> P;
    int length = P.length();
        int i = 0;
        int sum = 0;
        while(length--){
            if(P.at(i) == 'H' || P.at(i) == 'Q' || P.at(i) == '9'){
                sum++;
                break;
            }
            i++;            
        }
        if(sum == 1){
            cout << "YES";
        }
        else{
            cout << "NO";
        }
    
    
    return 0;
}
