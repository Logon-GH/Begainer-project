//https://codeforces.com/contest/520/problem/A
#include<bits/stdc++.h>
using namespace std;
 
int main(){
 
    int n;
    cin >> n;
    string word;
    cin >> word;
    set<char> set1;
        for(int i = 0; i < n; i++){
                if(word.at(i) < 96){
                    word.at(i) += 32;
                }
                set1.insert(word.at(i));
        }
        if(set1.size() == 26){
            cout << "YES";
        }
        else{
            cout << "NO";
        }
    
    
    
    return 0;
}
