//https://codeforces.com/contest/469/problem/A
#include<bits/stdc++.h>
using namespace std;
 
int main(){
 
    int n;
    cin >> n;
    int x , y , xp , yp;
    cin >> x;
    set<int> set1;
        for(int i = 0; i < x; i++){
            cin >> xp;
            set1.insert(xp);
        }
        cin >> y;
        for(int i = 0; i < y; i++){
            cin >> yp;
            set1.insert(yp);
        }
        if(set1.size() == n){
            cout << "I become the guy.";
        }
        else{
            cout << "Oh, my keyboard!";
        }
    
    
    
    return 0;
}
