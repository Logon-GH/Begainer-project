//https://codeforces.com/contest/144/problem/A
#include<bits/stdc++.h>
using namespace std;
 
int main(){
 
    int n,s;
    cin >> n;
    int max = 0, maxi, min = 100, mini, sum = 0;
        vector<int> v1 ={};
        for(int i = 0; i < n; i++){
            cin >> s;
            v1.push_back(s);
                if(v1[i] > max){
                    max = v1[i];
                    maxi = i;
                }
                if(v1[i] <= min){
                min = v1[i];
                mini = i;
            }
        }
        if(maxi > mini){
            mini++;
        }
        sum += maxi;
        sum += ((v1.size() - 1) - mini);
        cout << sum;
        
 
 
        
    
    
    
    return 0;
}
