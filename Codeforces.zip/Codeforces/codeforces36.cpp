//https://codeforces.com/contest/479/problem/A
#include<bits/stdc++.h>
using namespace std;
 
int main(){
 
    int x,y,z,max = 0;
    cin >> x >> y >> z;
        if(x + y * z > max){
            max = x + y * z;
        }
        if(x * (y + z) > max){
            max = x * (y + z);
        }
        if(x * y * z > max){
            max = x * y * z;
        }
        if((x + y) * z > max){
            max = (x + y) * z;
        }
        if(x + y + z > max){
            max = x + y + z;
        }
        cout << max;
    
 
    return 0;
}
