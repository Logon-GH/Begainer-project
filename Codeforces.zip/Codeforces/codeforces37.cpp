//https://codeforces.com/contest/148/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int k, l ,m ,n ,d;
    cin >> k >> l >> m >> n >> d;
        if(k == 1 || l == 1 || m == 1 || n == 1){
            cout << d;
        }
        else{
            int sum = 0;
            for(int i = 2; i <= d; i++){
                if(i % k == 0){
                    sum++;
                }
                else if(i % l == 0){
                    sum++;
                }
                else if(i % m == 0){
                    sum++;
                }
                else if(i % n == 0){
                    sum++;
                }
            }
            cout << sum;
        }
    
 
    return 0;
}
