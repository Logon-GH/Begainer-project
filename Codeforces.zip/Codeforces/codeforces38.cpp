//https://codeforces.com/contest/785/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int n;
    string word;
    int sum = 0;
    cin >> n;
        for(int i = 0; i < n; i++){
            cin >> word;
                if(word == "Tetrahedron"){
                    sum += 4;
                }
                else if(word == "Cube"){
                    sum += 6;
                }
                else if(word == "Octahedron"){
                    sum += 8;
                }
                else if(word == "Dodecahedron"){
                    sum += 12;
                }
                else if(word == "Icosahedron"){
                    sum += 20;
                }
        }
        cout << sum;
    
 
    return 0;
}
