//https://codeforces.com/contest/443/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    string word;
    set<char> set1;
    getline(cin , word);
        for(int i = 0; i < word.length(); i++){
            set1.insert(word.at(i));
        }
        if(set1.count(',') && set1.count(' ')){
            cout << set1.size() - 4;
        }
        else if(set1.size() == 3){
            cout << "1";
        }
        else{
            cout << "0";
        }
    
 
    return 0;
}
