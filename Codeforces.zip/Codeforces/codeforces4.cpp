//https://codeforces.com/contest/282/problem/A
#include<iostream>
 
int main(){
 
    int input;
    std::cin >> input;
    std::string word[1000];
    int x = 0;
    for(int i = 0; i < input; i++){
        std::cin >> word[i];
        if(word[i].at(0) == '+' || word[i].at(2) == '+'){
            x++;
        }
        else if(word[i].at(0) == '-' || word[i].at(2) == '-'){
            x--;
        }
    }         
        std::cout << x ;
 
    return 0;
}
