//https://codeforces.com/contest/4/problem/C
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int n;
    cin >> n;
    map<string , int> name;
        for(int i = 0; i < n; i++){
            string word;
            cin >> word;
 
                if(name.find(word) == name.end()){
                    cout << "OK" << '\n';
                    name[word] = 1;
                }
                else{
                    cout << word << name[word] << '\n';
                    name[word]++;
                }
        } 
        
    
        
    
 
    return 0;
}
