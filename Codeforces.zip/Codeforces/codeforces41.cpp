//https://codeforces.com/contest/580/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int n , a;
    cin >> n;
    bool g = false;
    int sum = 1 , max = 0;
    vector<int> V;
        for(int i = 0; i < n; i++){
            cin >> a;
            V.push_back(a);
                if(g){
                    if(V[i - 1] <= V[i]){
                        sum++;
                            if(sum >= max){
                                max = sum;
                            }
                    }
                    else{
                        sum = 1;
                            if(sum >= max){
                                max = sum;
                            }
                    }
 
                }
                if(n == 1){
                    max = 1;
                }
                g = true;
        }
        cout << max;
        
        
    
        
    
 
    return 0;
}
