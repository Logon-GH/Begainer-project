//https://codeforces.com/contest/510/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int n, m;
    cin >> n >> m;
    bool v = true;
        for(int i = 1; i <= n; i = i + 2){
            for(int j = 0; j < m; j++){
                cout << "#";
            }
            cout << "\n";
            if(i < n){
                if(v){
                    for(int k = 0; k < m - 1; k++){
                        cout << ".";
                    }
                    cout << "#";
                    v = false;
                }
                else{
                    cout << "#";
                    for(int k = 0; k < m - 1; k++){
                        cout << ".";
                    }
                    v = true;
 
                }    
            }
            cout << "\n";
            
        }
    
        
        
    
        
    
 
    return 0;
}
