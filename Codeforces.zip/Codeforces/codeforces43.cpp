//https://codeforces.com/contest/1335/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int t;
    cin >> t;
        while(t--){
            int n , sum = 0;
            cin >> n;
                for(int i = (n / 2) + 1; i < n; i++){
                    sum++;
                }
                cout << sum << "\n"; 
        }
 
    return 0;
}
