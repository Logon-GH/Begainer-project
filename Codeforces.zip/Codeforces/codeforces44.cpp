//https://codeforces.com/contest/2172/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int a, b, c;
    vector<int> v;
    cin >> a >> b >> c;
    v.push_back(a);
    v.push_back(b);
    v.push_back(c);
    sort(v.begin(), v.end());
 
    int sum = v[2] - v[0];
        if(sum < 10){
            cout << "final " << v[1];
        }
        else{
            cout << "check again";
        }
 
 
    return 0;
}
