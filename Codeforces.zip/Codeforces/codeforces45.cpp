//https://codeforces.com/gym/104441/problem/1
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int n,m,s,b,m2,s2,b2;
    cin >> n >> m >> s >> b;
    m2 = m * n;
    s2 = s * n;
        while(s2 >= 60){
            s2 -= 60;
            m2++;
        }
        b2 = b * (n - 1);
        while(b2 >= 60){
            b2 -= 60;
            m2++;
        }
        s2 += b2;
        while(s2 >= 60){
            s2 -= 60;
            m2++;
        }
        cout << m2 << "\n" << s2;
 
 
 
    return 0;
}
