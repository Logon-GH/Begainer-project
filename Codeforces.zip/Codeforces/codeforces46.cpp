//https://codeforces.com/contest/1352/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int n;
    cin >> n;
    vector<int> v;
    int power = 1;
    while(n--){
        int t;
        cin >> t;  
        while(t > 0){
            int tt = t % 10;
                if(tt > 0){
                    v.push_back(tt * power);
                }
                t = t / 10;
                power *= 10;
            } 
        cout << v.size() << "\n";
        for(int x : v){
            cout << x << " ";
        }
        cout << "\n";
        power = 1;  
        v.clear();
    }
    
 
 
    return 0;
}
