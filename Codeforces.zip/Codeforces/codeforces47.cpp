//https://codeforces.com/contest/141/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    string w,w1,w2;
    cin >> w >> w1 >> w2;
    w += w1;
    sort(w.begin(), w.end());
    sort(w2.begin(), w2.end());
        if(w == w2){
            cout << "YES";
        }
        else{
            cout << "NO";
        }
 
    
 
    return 0;
}
