//https://codeforces.com/contest/1742/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int n;
    cin >> n;
    while(n--){
        int a,b,c;
        cin >> a >> b >> c;
            if(a + b == c || b + c == a || a + c == b){
                cout << "YES\n";
            }
            else{
                cout << "NO\n";
            }
    }
 
    
 
    return 0;
}
