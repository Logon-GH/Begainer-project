//https://codeforces.com/contest/50/problem/A
#include<iostream>
//Domaino pilling
int main(){
 
    int m,n;
    std::cin >> m >> n;
    int total = m * n;
    int divide = total/2;
    std::cout << divide;
 
    return 0;
}
