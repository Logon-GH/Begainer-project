//https://codeforces.com/contest/131/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    string w;
    cin >> w;
    bool t = true;
        for(int i = 1; i < w.length(); i++){
            if(w.at(i) > 96){
                t = false;
            }
        }
        if(t){
            if(w.at(0) > 96){
                w.at(0) -= 32;
                    for(int i = 1; i < w.length(); i++){
                        w.at(i) += 32;
                    }
            }
            else{
                for(int i = 0; i < w.length(); i++){
                    w.at(i) += 32;
                }
            }
        }
        cout << w;    
 
    
 
    return 0;
}
