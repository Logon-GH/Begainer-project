//https://codeforces.com/contest/427/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int n,a;
    int p = 0,c = 0;
    cin >> n;
    while(n--){
        cin >> a;
            if(a > 0){
                p += a;
            }
            else{
                if(p > 0){
                    p += a;
                }
                else{
                    c++;
                }
            }
 
    }
    cout << c;
        
 
 
    
 
    return 0;
}
