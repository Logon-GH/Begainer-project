//https://codeforces.com/contest/337/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int n,m,p;
    cin >> n >> m;
    vector<int> v(m);
    for(int i = 0; i < m; i++){
        cin >> v[i];
    }
    sort(v.begin(), v.end());
    int min = INFINITY;
    for(int i = 0; i <= m - n; i++){
        int c = v[i + n - 1] - v[i];
            if(c < min){
                min = c;
            }
    }
    cout << min;
 
    
    
    
 
    return 0;
}
