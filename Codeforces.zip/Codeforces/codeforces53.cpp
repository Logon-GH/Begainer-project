//https://codeforces.com/contest/2171/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
 
    int t;
    int sum = 1;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        if(n % 2 == 1){
            cout << 0 << '\n';
        }
        else if(n == 0){
            cout << 0 << '\n';
        }
        else{
            if(n % 4 == 0){
                sum++;
            }
            for(int i = 4; i < n; i = i + 4){
                for(int j = i; j <= n; j = j + 2){
                    if(j == n){
                        sum++;
                    }
                }
                    
            }
            cout << sum << '\n';
            sum = 1;
        }
        
    }
 
    return 0;
}
