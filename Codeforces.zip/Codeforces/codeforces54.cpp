//https://codeforces.com/contest/151/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n,k,l,c,d,p,nl,np;
    cin >> n >> k >> l >> c >> d >> p >> nl >> np;
    k = ((k * l) / nl) / n;
    c = (c * d) / n;
    p = (p / np) / n;
    cout << min(k, min(c , p));
    
 
    return 0;
}
