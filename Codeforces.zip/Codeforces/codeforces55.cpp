//https://codeforces.com/contest/1703/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        string s;
        cin >> s;
        for(int i = 0; i < 3; i++){
            if(s.at(i) > 96){
                s.at(i) -= 32; 
            }
        }
        if(s == "YES"){
            cout << "YES\n";
        }
        else{
            cout << "NO\n";
        }
    }
    
 
    return 0;
}
