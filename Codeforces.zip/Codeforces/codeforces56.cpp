//https://codeforces.com/contest/155/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
   int n, sum = -2, max = -1, min = 100000;
   cin >> n;
   while(n--){
        int p;
        cin >> p;
        if(p > max){
            max = p;
            sum++;
        }
        if(p < min){
            min = p;
            sum++;
        }
   }
   cout << sum;
    
 
    return 0;
}
