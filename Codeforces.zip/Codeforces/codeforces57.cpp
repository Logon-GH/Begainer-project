//https://codeforces.com/contest/750/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int p, t, sum = 0;
    cin >> p >> t;
    for(int i = 1; i <= p; i++){
        t += 5 * i;
        if(t > 240){
            break;
        }
        sum++;
    }
    cout << sum;
    
    
 
    return 0;
}
