//https://codeforces.com/contest/381/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int n,s = 0, d = 0;
    cin >> n;
    vector<int> p(n);
    for(int i = 0; i < n; i++){
        cin >> p[i]; 
    }
    int left = 0, right = n - 1;
    bool pp = true;
    while(left <= right){
        if(p[left] < p[right]){
            if(pp){
                s += p[right];
                pp = false;
            }
            else{
                d += p[right];
                pp = true;
            }
            right--;
        }
        else{
            if(pp){
                s += p[left];
                pp = false;
            }
            else{
                d += p[left];
                pp = true;
            }
            left++;
        }
    }
    cout << s << " " << d;
 
       
    return 0;
}
