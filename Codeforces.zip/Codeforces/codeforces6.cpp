//https://codeforces.com/contest/263/problem/A
#include<iostream>
//bueatiful matrix
int main(){
 
    int row,column,num;
 
    for(int i = 1; i < 6; i++){
        for(int j = 1; j < 6; j++){
            std::cin >> num;
                if(num == 1){
                    row = i;
                    column = j;
                }
        }
    }
    int value = abs(row - 3) + abs(column - 3);
    std::cout << value;
 
    return 0;
}
