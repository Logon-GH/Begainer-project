//https://codeforces.com/contest/1154/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int a,b,c,d;
    cin >> a >> b >> c >> d; 
    int m = max(a , max(b , max(c , d)));
    if(m > a){
        cout << m - a <<" ";
    }
    if(m > b){
        cout << m - b <<" ";
    }
    if(m > c){
        cout << m - c <<" ";
    }
    if(m > d){
        cout << m - d <<" ";
    }
       
    return 0;
}
