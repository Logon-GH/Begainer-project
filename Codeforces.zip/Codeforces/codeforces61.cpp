//https://codeforces.com/contest/1669/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        int r;
        cin >> r;
            if(r <= 1399){
                cout << "Division 4\n";
            }
            else if(r >= 1900){
                cout << "Division 1\n";
            }
            else if(r >= 1600 && r <= 1899){
                cout << "Division 2\n";
            }
            else{
                cout << "Division 3\n";
            }
    }
       
    return 0;
}
