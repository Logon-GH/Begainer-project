//https://codeforces.com/contest/581/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int a,b;
    cin >> a >> b;
    cout << min(a , b) << " ";
    cout << abs((a - b) / 2);
 
       
    return 0;
}
