//https://codeforces.com/contest/1692/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        int a,b,c,d;
        int sum = 0;
        cin >> a >> b >> c >> d;
        if(a < b){
            sum++;
        }
        if(a < c){
            sum++;
        }
        if(a < d){
            sum++;
        }
        cout << sum << "\n";
    }
 
       
    return 0;
}
