//https://codeforces.com/contest/1676/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        int a;
        int i = 5;
        vector<int> p(6);
        cin >> a;
        while(a > 0){
            p[i] = a % 10;
            a = a / 10;
            i--;
        }
        if(p[0] + p[1] + p[2] == p[3] + p[4] + p[5]){
            cout << "YES\n";
        }
        else{
            cout << "NO\n";
        }
        p.clear();
    }
 
       
    return 0;
}
