//https://codeforces.com/contest/1807/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        int a,b,c;
        cin >> a >> b >> c;
        if(a + b == c){
            cout << "+\n";
        } 
        else{
            cout << "-\n";
        }
    }
 
       
    return 0;
}
