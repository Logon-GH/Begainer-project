//https://codeforces.com/contest/1475/problem/A
#include<bits/stdc++.h>
using namespace std;
#define ll long long
 
int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
 
    int tt;
    cin >> tt;
    while(tt--){
        ll n;
        cin >> n;
        if(n % 2 == 1){
            cout << "YES\n";
        }
        else{
            while(n % 2 == 0){
                n = n / 2;
            }
            if(n > 1){
                cout << "YES\n";
            }
            else{
                cout << "NO\n";
            }
        }
    }
 
       
    return 0;
}
