//https://codeforces.com/contest/236/problem/A
#include<iostream>
#include<algorithm>
//https://codeforces.com/problemset/problem/236/A
int main(){
 
    std::string word;
    std::cin >> word;
    sort(word.begin(),word.end());
    int length = word.length();
    int sum = 0;
        for(int i = 0; i < length - 1; i++){
            if(word.at(i) == word.at(i + 1)){
 
            }
            else{
                sum++;
            }
        }
        if((sum + 1) % 2 == 0){
            std::cout << "CHAT WITH HER!" << std::endl;
        }
        else{
            std::cout << "IGNORE HIM!" << std::endl;
        }
        
 
    return 0;
}
