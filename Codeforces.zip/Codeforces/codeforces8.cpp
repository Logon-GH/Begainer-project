//https://codeforces.com/contest/339/problem/A
#include<iostream>
#include<algorithm>
//https://codeforces.com/problemset/problem/339/A
 
int main(){
 
    std::string word; 
    std::cin >> word;
    int length = word.length();
    sort(word.begin(),word.end());
    int sum = 0;
        for(int i = 0; i < length -1; i++){
            if(word.at(i) == 43){
                sum++;
            }
        }
        word.erase(0, sum);
            for(int j = 1; j < length - 1; j = j + 2){
                word.insert(j , "+");
            }
        
    std::cout << word;
    
        
        
 
    return 0;
}
