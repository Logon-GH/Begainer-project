//https://codeforces.com/contest/281/problem/A
#include<iostream>
//https://codeforces.com/problemset/problem/281/A
 
int main(){
 
    std::string word;
    std::cin >> word;
        if(word.at(0) > 96){
            int a = word.at(0);
            int b = a - 32;
            word.at(0) = b;
            std::cout << word;
        }
        else{
            std::cout << word;
        }
        
 
    return 0;
}
